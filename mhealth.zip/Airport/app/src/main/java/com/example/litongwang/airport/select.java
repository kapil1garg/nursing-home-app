package com.example.litongwang.airport;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import com.google.android.gms.common.api.GoogleApiClient;
import android.app.Activity;

public class select extends Activity {

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;
    private int activity;
    private Button submit;
    private TextView final_text;
    private int time;
    private boolean user;


    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select);
        Intent intent=getIntent();
        final_text = (TextView)findViewById(R.id.result_text);
      //  Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
     //   setSupportActionBar(toolbar);

        submit = (Button)findViewById(R.id.submit_button);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText Time;
                Time = (EditText) findViewById(R.id.duration);
                time = new Integer(Time.getText().toString());
                Log.d("select", Time.getText().toString());
                Intent intent1 = new Intent();
                intent1.setClass(select.this, MainActivity.class);
                startActivity(intent1);
                //upload the activity and time
            }
        });

    }

    public void selectActivity(View view){
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()){
            case R.id.toilet_button:
                if (checked){
                    activity=1;
                    final_text.setText("You are pooping!");
                    final_text.setEnabled(true);
                }else{
                    final_text.setEnabled(false);
                }
                break;
            case R.id.shower_button:
                if (checked){
                    activity=2;
                    final_text.setText("You are showering!");
                    final_text.setEnabled(true);
                }else{
                    final_text.setEnabled(false);
                }
                break;
            case R.id.dressing_button:
                if (checked){
                activity=3;
                final_text.setText("You are dressing!");
                final_text.setEnabled(true);
            }else{
                final_text.setEnabled(false);
            }
            break;
            case R.id.prepare_button:
                if (checked){
                    activity=4;
                    final_text.setText("You are preparing food!");
                    final_text.setEnabled(true);
                }else{
                    final_text.setEnabled(false);
                }
                break;
            case R.id.others_button:
                if (checked){
                    activity=5;
                    final_text.setText("You are doing something else!");
                    final_text.setEnabled(true);
                }else{
                    final_text.setEnabled(false);
                }
                break;
            case R.id.yes_button:
                if (checked){
                    user=true;
                }else{
                    final_text.setEnabled(false);
                }
                break;
            case R.id.no_button:
                if (checked){
                    user=false;
                }else{
                    final_text.setEnabled(false);
                }
                break;
        }
    }
}
