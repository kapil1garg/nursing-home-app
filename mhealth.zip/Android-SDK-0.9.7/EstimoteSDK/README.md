JavaDoc documentation is available:
 - as download from [GitHub pages branch](https://github.com/Estimote/Android-SDK/tree/gh-pages)
 - browsable form: http://estimote.github.com/Android-SDK/JavaDocs
