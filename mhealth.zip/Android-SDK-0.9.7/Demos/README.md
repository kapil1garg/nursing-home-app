How to run demos?
=====================

You can easily build it with Gradle by typing `./gradlew installDebug` (or `gradlew.bat installDebug` on Windows) in terminal when your device is connected to computer. If you use [Android Studio](https://developer.android.com/sdk/index.html) you can just simply open build.gradle.
