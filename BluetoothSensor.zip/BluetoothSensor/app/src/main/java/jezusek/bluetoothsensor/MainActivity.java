package jezusek.bluetoothsensor;

import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.estimote.sdk.BeaconManager;
import com.estimote.sdk.Region;
import com.estimote.sdk.SystemRequirementsChecker;

import java.util.UUID;


public class MainActivity extends AppCompatActivity {

    TextView output, signal;
//Every Second updates the field for the strongest beacon
    Runnable r2=new Runnable() {
        @Override
        public void run() {
            MyApplication x = (MyApplication)getApplicationContext();
            output.setText(Integer.toString(x.connected));
            signal.setText(Float.toString(x.signal));
        }
    };
//Resets the list of the estimote that have been activated
    Runnable r3=new Runnable() {
        @Override
        public void run() {
            MyApplication x = (MyApplication)getApplicationContext();
            x.connectionOrder.clear();
        }
    };

    Handler h2=new Handler();
    Handler h3=new Handler();


    @Override
    protected void onResume() {
        super.onResume();
        h2.postDelayed(r2, 1000);
        h3.postDelayed(r3, 240000);

        SystemRequirementsChecker.checkWithDefaultDialogs(this);
        beaconManager.connect(new BeaconManager.ServiceReadyCallback() {
            @Override
            public void onServiceReady() {
                beaconManager.startRanging(region);
            }
        });


    }
    @Override
    protected void onPause() {
        beaconManager.stopRanging(region);
        h2.removeCallbacks(r2);

        super.onPause();
    }
    private BeaconManager beaconManager;
    private Region region;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        MyApplication x = (MyApplication)getApplicationContext();

        output = (TextView) findViewById(R.id.connectTV);
        signal = (TextView) findViewById(R.id.signalTV);



        beaconManager = new BeaconManager(this);
        region = new Region("ranged region",
                UUID.fromString("B9407F30-F5F8-466E-AFF9-25556B57FE6D"), null, null);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
